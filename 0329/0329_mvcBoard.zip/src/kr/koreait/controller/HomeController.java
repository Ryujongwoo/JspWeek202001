package kr.koreait.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.koreait.vo.MvcBoardVO;

@WebServlet("*.nhn")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HomeController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		String url = request.getRequestURI();
		String contextPath = request.getContextPath();
		String context = url.substring(contextPath.length());
		
		String viewPage = "/WEB-INF/";
		switch(context) {
			case "/insert.nhn":
				viewPage += "insert";
				break;
			case "/insertOK.nhn":
				viewPage += "insertOK";
//				System.out.println("name: " + request.getParameter("name"));
//				System.out.println("subject: " + request.getParameter("subject"));
//				System.out.println("content: " + request.getParameter("content"));
				String name = request.getParameter("name");
				String subject = request.getParameter("subject");
				String content = request.getParameter("content");
				MvcBoardVO vo = new MvcBoardVO(name, subject, content);
				System.out.println(vo);
//				서비스 클래스의 데이터를 테이블에 저장하는 메소드를 실행한다.
				
				viewPage += "list";
				break;
		}
		viewPage += ".jsp";
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
		
	}

}




















