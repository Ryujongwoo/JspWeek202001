package my.dao;

import org.apache.ibatis.session.SqlSession;

import my.model.Memo;
import my.mybatis.MySession;

public class MemoDao {
	private static MemoDao instance = new MemoDao();
	private MemoDao(){};
	public static MemoDao getInstance(){
		return instance;
	}
	//=================================================
	public int insert(Memo m){
		SqlSession session = MySession.getSession();
		int cnt = session.insert("insertMemo", m);
		session.commit();
		session.close();
		return cnt;
	}
	public int getCount(){
		SqlSession session  = MySession.getSession();
		int cnt = (Integer)session.selectOne("getCount");
		session.close();
		return cnt;
	}
	public Memo selectByIdx(int idx){
		SqlSession session  = MySession.getSession();
		Memo m = (Memo)session.selectOne("selectByIdx",idx);
		session.close();
		return m;
	}
}
