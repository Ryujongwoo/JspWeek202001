//	함수의 형식
//	function 함수이름([인수, ...]) {
//		함수가 실행할 문장;
//		...;
//		[return 값;]
//	}

//	moveNext(이벤트가 실행되는 객체, 최대 글자수, 포커스를 넘겨줄 객체)
//	이벤트가 실행되는 객체(주민등록번호 앞, 뒤 자리)에 최대 글자수 만큼 문자가 입력되면 지정된 객체로 포커스를 넘겨준다.
	function moveNext(obj, len, nextObj) {
//	value => 객체에 입력된 데이터를 의미한다. 데이터가 입력된 상태면 true, 그렇치 않으면 false
//	length => 객체에 입력된 문자의 개수를 얻어온다.
		if(obj.value.length == len) {
			nextObj.focus();
		}
	}

//	formCheck(검사할 데이터가 입력된 폼)
//	obj로 this(폼)가 넘어오므로 obj에는 document.juminForm이 저장된다.
	function formCheck(obj) {
//		alert(obj.jumin1.value);

//		주민등록번호 앞 자리에 데이터가 입력되었나 검사해서 입력되지 않았으면 false를 리턴시킨다.
//		!obj.jumin1.value => 아무것도 입력되지 않았는가?
		if(!obj.jumin1.value || obj.jumin1.value.trim().length == 0) {
			alert("주민등록번호 앞 자리를 입력하세요!!!");
			obj.jumin1.value = "";
			obj.jumin1.focus();
			return false;
		}

//		주민등록번호 앞 자리에 6글자가 입력되었나 검사해서 입력되지 않았으면 false를 리턴시킨다.
		if(obj.jumin1.value.trim().length != 6) {
			alert("주민등록번호 앞 자리는 6글자를 입력하세요!!!");
			obj.jumin1.value = "";
			obj.jumin1.focus();
			return false;
		}

//		주민등록번호 앞 자리에 숫자만 입력되었나 검사해서 입력되지 않았으면 false를 리턴시킨다.
//		Number() => 인수로 지정된 문자열을 숫자로 변환한다.
//		isNaN() => NaN(Not a Number), 인수로 지정된 데이터가 숫자가 아니면 true, 숫자면 false를 리턴한다.
		if(isNaN(Number(obj.jumin1.value.trim()))) {
			alert("주민등록번호 앞 자리는 숫자만 입력해야 합니다!!!");
			obj.jumin1.value = "";
			obj.jumin1.focus();
			return false;
		}
		
		if(!obj.jumin2.value || obj.jumin2.value.trim().length == 0) {
			alert("주민등록번호 뒷 자리를 입력하세요!!!");
			obj.jumin2.value = "";
			obj.jumin2.focus();
			return false;
		}
		if(obj.jumin2.value.trim().length != 7) {
			alert("주민등록번호 뒷 자리는 7글자를 입력하세요!!!");
			obj.jumin2.value = "";
			obj.jumin2.focus();
			return false;
		}
		if(isNaN(Number(obj.jumin2.value.trim()))) {
			alert("주민등록번호 뒷 자리는 숫자만 입력해야 합니다!!!");
			obj.jumin2.value = "";
			obj.jumin2.focus();
			return false;
		}
		
//		여기까지 왔다는 것은 입력된 주민등록번호가 13자리의 숫자로 입력되었다는 의미이다. => 유효성을 검사한다.
//		주민등록번호 유효성을 검사하기 위해 주민등록번호를 하나의 문자열로 합친다.
		var jumin = obj.jumin1.value.trim() + obj.jumin2.value.trim();
//		var jumin = Number(obj.jumin1.value.trim()) + Number(obj.jumin2.value.trim());
//		javascript는 숫자로만 구성된 문자열을 사칙연산을 할 경우 덧셈을 하는 경우에는 문자열을 이어주고 덧셈을 제외한 나머지 연산은
//		지가 알아서 숫자로 변환한 후 연산한다.
//		alert(jumin)
//		주민등록번호 유효성을 검사한다. 가중치 => 234567892345, 둘리 주민등록번호 => 8304221185600 => 가중치와 곱해서 더하면 143

//		주민등록번호의 각자리 숫자에 가중치를 곱한 합계를 계산한다.
		sum = 0;
		for(i = 0; i < 12; i++) {
//			sum += jumin.charAt(i) * (i < 8 ? i + 2 : i - 6);
			sum += jumin.charAt(i) * (i % 8 + 2);
		}
//		alert(sum);

//		주민등록번호 각 자리와 가중치를 곱한 합계를 11로 나눈 나머지를 11에서 뺀 결과가 주민등록번호 마지막 자리와 일치하면 정상,
//		그렇치 않으면 오류 => 나머지를 11에서 뺀 결과가 2자리 숫자면 10의 자리는 버리고 1의 자리만 취한다.
		result = (11 - sum % 11) % 10;
		
		if(result != jumin.charAt(12)) {
			alert("주민등록번호 올바르지 않습니다!!!");
			obj.jumin1.value = "";
			obj.jumin2.value = "";
			obj.jumin1.focus();
			return false;
		}

//		폼에 오류없이 여기까지 실행되면 정상적인 데이터가 입력된 것이므로 true를 리턴한다.
		return true;
	}