package kr.koreait.onlinepoll;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class PollWrite {

//	텍스트 파일을 저장할 경로와 이름, ArrayList를 넘겨받아 ArrayList에 저장된 데이터를 텍스트 파일에 저장하는 메소드
	public static void pollWrite(String filename, ArrayList<String> poll) {
		
//		ArrayList에 저장된 데이터를 텍스트 파일로 출력할 PrintWriter 객체를 선언한다.
		PrintWriter printWriter = null;
		
		try {
//			ArrayList에 저장된 데이터를 텍스트 파일로 출력할 PrintWriter 객체를 생성한다.
			printWriter = new PrintWriter(filename);
			
//			텍스트 파일로 출력할 객체가 생성되었으면 ArrayList에 저장된 데이터의 개수 만큼 반복하며 텍스트 파일로 저장한다.
			for(String str : poll) {
//				텍스트 파일로 한 줄 출력하고 줄을 바꾸기 위해서 "\r\n"를 같이 출력해야 한다.
//				"\r"을 사용하지 않으면 줄바꿈 처리는 되지만 텍스트 파일을 열었을 때 화면에는 줄이 변경되지 않아보인다.
				printWriter.write(str + "\r\n");
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("디스크에 파일이 존재하지 않습니다.");
			e.printStackTrace();
		} finally {
//			텍스트 파일로 출력에 사용한 객체를 받드시 닫아야 한다. => 닫지 않으면 텍스트 파일에 데이터가 저장되지 않는다.
			if(printWriter != null) { printWriter.close(); }
		}
		
	}
	
}




















