package kr.koreait.service;

import java.sql.SQLException;
import java.util.HashMap;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.koreait.dao.GuestbookDAO;
import kr.koreait.ibatis.MyAppSqlConfig;
import kr.koreait.vo.GuestbookList;
import kr.koreait.vo.GuestbookVO;

//	SelectService 클래스는 select sql 명령이 실행되기 전에 실행해야 할 작업이 있으면 실행하는 클래스
public class SelectService {

	private static SelectService instance = new SelectService();
	private SelectService() { }
	public static SelectService getInstance() {
		return instance;
	}

//	list.jsp에서 호출되는 화면에 표시할 페이지 번호를 넘겨받고 mapper를 얻어온 후 dao 클래스의 1페이지 분량의 글 목록을 얻어오는 메소드를 호출하는
//	메소드
	public GuestbookList selectList(int currentPage) {
		System.out.println("SelectService 클래스의 selectList() 메소드 실행");
		SqlMapClient mapper = MyAppSqlConfig.getSqlMapInstance();
		
//		1페이지 분량의 글과 페이지 작업에 사용할 8개의 변수의 값을 저장하는 객체를 선언한다.
		GuestbookList guestbookList = null;
		GuestbookDAO dao = GuestbookDAO.getInstance();
		
		try {
//		1페이지에 표시할 글의 개수를 정한다.
			int pageSize = 10;
//		테이블에 저장된 전체 글의 개수를 얻어온다.
			int totalCount = dao.selectCount(mapper);
//			System.out.println(totalCount);
			
//			pageSize, totalCount, currentPage를 생성자의 인수로 넘겨서 1페이지 분량의 글과 페이지 작업에 사용할 8개의 변수를 초기화 시키는
//			클래스(GuestbookList)의 객체를 생성한다.
			guestbookList = new GuestbookList(pageSize, totalCount, currentPage);
			
//			parameterClass와 resultClass에는 반드시 데이터 타입을 1개만 적어야 한다.
			HashMap<String, Integer> hmap = new HashMap<String, Integer>();
			hmap.put("startNo", guestbookList.getStartNo());
			hmap.put("endNo", guestbookList.getEndNo());
//			mysql은 아래와 같이 endNo 대신 pageSize를 HashMap에 저장해서 넘겨야 한다.
//			hmap.put("pageSize", guestbookList.getPageSize());
			
//			테이블에서 1페이지 분량의 글 목록을 얻어와 GuestbookList 클래스의 guestbookList ArrayList에 저장한다.
			guestbookList.setGuestbookList(dao.selectList(mapper, hmap));
//			System.out.println(guestbookList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return guestbookList;
	}
	
//	selectByIdx.jsp에서 호출되는 수정 또는 삭제할 글의 글번호를 넘겨받고 mapper를 얻어온 후 dao 클래스의 글 1건을 얻어오는 메소드를 호출하는
//	메소드
	public GuestbookVO selectByIdx(int idx) {
		System.out.println("SelectService 클래스의 selectByIdx() 메소드 실행");
		SqlMapClient mapper = MyAppSqlConfig.getSqlMapInstance();
		GuestbookVO vo = null;
		try {
			vo = GuestbookDAO.getInstance().selectByIdx(mapper, idx);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vo;
	}
	
	
}






















